class SummarizeDBAssertString:
    QUERY_AND_TABLE_SET = "Set --query flag and --table_name/--alias flag"
    ALIAS_OR_TABLE_ONLY = "Set --alias or --table_name flag only"
