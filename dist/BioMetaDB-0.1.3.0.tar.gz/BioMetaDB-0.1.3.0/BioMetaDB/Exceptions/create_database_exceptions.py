class CreateDBAssertString:
    WORKING_DIR_EXISTS = "Directory exists, exiting"
    WORKING_DB_NOT_SET = "Database name not set"
    SEQUENCE_DIR_NOT_EXISTS = "Sequence directory does not exist, exiting"
    TABLE_NAME_NOT_SET = "Record name not set"
