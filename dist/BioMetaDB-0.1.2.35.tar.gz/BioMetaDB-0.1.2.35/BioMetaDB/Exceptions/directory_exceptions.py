class DirectoryAssertString:
    DIRECTORY_NOT_EXIST = "Genome directory does not exist, exiting"
