from BioMetaDB.Exceptions.error import Error


class ColumnNameNotFoundError(Error):
    pass
