from BioMetaDB.Exceptions.error import Error


class SequenceIdNotFoundError(Error):
    pass


class ImproperFormatIndexFileError(Error):
    pass
