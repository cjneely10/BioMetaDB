class Directories:
    DATABASE = "db"
    CLASSES = "classes"
    CONFIG = "config"
    MIGRATIONS = "migrations"
