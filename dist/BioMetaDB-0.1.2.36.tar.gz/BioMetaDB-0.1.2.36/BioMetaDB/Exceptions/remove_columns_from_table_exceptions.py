from BioMetaDB.Exceptions.error import Error


class ListFileNotProvidedError(Error):
    pass
