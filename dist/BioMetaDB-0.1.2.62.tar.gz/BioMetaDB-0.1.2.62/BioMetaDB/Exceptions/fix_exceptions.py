class FixAssertString:
    FIX_NOT_FOUND = "Fix file not found or missing .fix extension"
    BAD_PROJECT_DIR = "Project directory passed does not exist"
    INTERNAL_BAD_KWARGS = "INTERNAL ERROR: Bad **kwargs passed"
